#!/usr/bin/env python
# coding: utf-8

# In[1]:


#Create a TensorFlow Session


# In[2]:


import tensorflow as tf
sess = tf.Session()
sess.close()


# In[ ]:


#Define constants and perform computation:
import tensorflow as tf

# define two constants
a = tf.constant(2)
b = tf.constant(3)

# perform computations with the constants
add = tf.add(a, b)
sub = tf.subtract(a, b)

# create a TensorFlow session
with tf.Session() as sess:
    # run the computations and print the results
    print("Addition:", sess.run(add))
    print("Subtraction:", sess.run(sub))


# In[ ]:


#Print Hello World
import tensorflow as tf

# create a TensorFlow session
with tf.Session() as sess:
    # print Hello World
    print(sess.run(tf.constant("Hello World!")))


# In[ ]:


import tensorflow as tf

# create variables for m and c
m = tf.Variable(2.0)
c = tf.Variable(1.0)

# create a placeholder for x
x = tf.placeholder(tf.float32)

# create a linear equation y = mx + c
y = tf.add(tf.multiply(m, x), c)

# create a TensorFlow session
with tf.Session() as sess:
    # initialize variables
    sess.run(tf.global_variables_initializer())

    # evaluate the equation for a scalar value of x
    print("For x=2.0, y=", sess.run(y, feed_dict={x: 2.0}))

    # evaluate the equation for a vector of 5 values of x
    x_values = [1.0, 2.0, 3.0, 4.0, 5.0]
    print("For x=[1.0, 2.0, 3.0, 4.0, 5.0], y=", sess.run(y, feed_dict={x: x_values}))

    # choose arbitrary values for m and c and evaluate the equation
    m_value = 3.0
    c_value = 2.0
    print("For m=3.0, c=2.0, and x=4.0, y=", sess.run(y, feed_dict={m: m_value, c: c_value, x: 4.0}))

